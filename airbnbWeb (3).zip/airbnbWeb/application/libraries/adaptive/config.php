<?php

$config = array(
  "environment" => "sandbox", # or live
  "userid" => "info-facilitator_api1.commercefactory.org",
  "password" => "1399139964",
  "signature" => "AFcWxV21C7fd0v3bYYYRCpSSRl31ABA-4mmfZiu.G30Dl3DKyBo9-GF8",
  // "appid" => "", # You can set this when you go live
);
