
        <!-- REVOLUTION SLIDER -->
        <div id="slider">


            <div id="rev_slider_30_1_wrapper" class="rev_slider_wrapper fullscreen-container" data-alias="Airbnb Homepage" style="background-color:transparent;padding:0px;">
                <!-- START REVOLUTION SLIDER 5.1 fullscreen mode -->
                <div id="rev_slider_30_1" class="rev_slider fullscreenbanner" style="display:none;" data-version="5.1">
                    <ul>
                       
                        <!-- SLIDE  -->
                        <li data-index="rs-125" data-transition="zoomout" data-slotamount="default" data-easein="Power4.easeInOut" data-easeout="Power4.easeInOut" data-masterspeed="2000" data-thumb="<?php echo base_url('assets/'); ?>images/hotel-casino-chaves-1.jpg" data-rotate="0" data-saveperformance="off" data-description="">

                            <!-- MAIN IMAGE -->
                            <img src="<?php echo base_url('assets/'); ?>images/slider/dummy.png" alt="" width="1920" height="1080" data-lazyload="<?php echo base_url('assets/'); ?>images/hotel-casino-chaves-1.jpg" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
                            <!-- LAYERS -->


                              <div data-start="1000" data-splitin="none" data-splitout="none" data-responsive_offset="on" style="z-index: 5; white-space: nowrap;text-align:center; position: absolute; width: 100%; top: 250px; left: 375px;">



                              <div class="col-md-5"><div id="custom-search-input">
                                    <div class="row">
                                        <label><h1  class="slider_input_lable">Book unique homes and experiences </br> all over the world.</h1></label>
                                        <div class="col-md-12">
                                        <input class="search-query form-control" placeholder="Homes for families in Shanghai" type="text">
                                        <span class="input-group-btn">
                                        <button class="btn btn-danger" type="button"> <span class=" glyphicon glyphicon-search"></span> </button>
                                        </span> </div>
                                        </div>
                              </div>
                            </div>



                            </div>


                         
                        </li>
                        <!-- SLIDE  -->


                             <li data-index="rs-132" data-transition="zoomout" data-slotamount="default" data-easein="Power4.easeInOut" data-easeout="Power4.easeInOut" data-masterspeed="2000" data-thumb="<?php echo base_url('assets/'); ?>images/hotel-casino-chaves-2.jpg" data-rotate="0" data-saveperformance="off" data-description="">
                            <!-- MAIN IMAGE -->
                            <img src="<?php echo base_url('assets/'); ?>images/slider/dummy.png" alt="" width="1920" height="1080" data-lazyload="<?php echo base_url('assets/'); ?>images/hotel-casino-chaves-2.jpg" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
                            <!-- LAYERS -->


                             <div data-start="1000" data-splitin="none" data-splitout="none" data-responsive_offset="on" style="z-index: 5; white-space: nowrap;text-align:center; position: absolute; width: 100%; top: 250px; left: 375px;">



                              <div class="col-md-5"><div id="custom-search-input">
                                    <div class="row">
                                        <label><h1  class="slider_input_lable">Book unique homes and experiences </br> all over the world.</h1></label>
                                        <div class="col-md-12">
                                        <input class="search-query form-control" placeholder="Restaurants in San Francisco" type="text">
                                        <span class="input-group-btn">
                                        <button class="btn btn-danger" type="button"> <span class=" glyphicon glyphicon-search"></span> </button>
                                        </span> </div>
                                        </div>
                              </div>
                            </div>



                            </div>

                           
                        </li>


                         <li data-index="rs-132" data-transition="zoomout" data-slotamount="default" data-easein="Power4.easeInOut" data-easeout="Power4.easeInOut" data-masterspeed="2000" data-thumb="<?php echo base_url('assets/'); ?>images/hotel-casino-chaves-3.jpg" data-rotate="0" data-saveperformance="off" data-description="">
                            <!-- MAIN IMAGE -->
                            <img src="<?php echo base_url('assets/'); ?>images/slider/dummy.png" alt="" width="1920" height="1080" data-lazyload="<?php echo base_url('assets/'); ?>images/hotel-casino-chaves-3.jpg" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
                            <!-- LAYERS -->


                             <div data-start="1000" data-splitin="none" data-splitout="none" data-responsive_offset="on" style="z-index: 5; white-space: nowrap;text-align:center; position: absolute; width: 100%; top: 250px; left: 375px;">



                              <div class="col-md-5"><div id="custom-search-input">
                                    <div class="row">
                                        <label><h1  class="slider_input_lable">Book unique homes and experiences </br> all over the world.</h1></label>
                                        <div class="col-md-12">
                                        <input class="search-query form-control" placeholder="Restaurants in San Francisco" type="text">
                                        <span class="input-group-btn">
                                        <button class="btn btn-danger" type="button"> <span class=" glyphicon glyphicon-search"></span> </button>
                                        </span> </div>
                                        </div>
                              </div>
                            </div>



                            </div>

                           
                        </li>


                    </ul>
                    <div class="tp-static-layers">
                    </div>
                    <div class="tp-bannertimer tp-bottom" style="visibility: hidden !important;"></div>
                </div>
            </div>
            <!-- END REVOLUTION SLIDER -->


        </div>
        <!-- END REVOLUTION SLIDER -->

<!-- Shop products -->

 <!--        <?php if ($this->session->flashdata('success')) { 
                             echo getMessage('success', $this->session->flashdata('success'));
                         }  if ($this->session->flashdata('error')) { 
                             echo  getMessage('error', $this->session->flashdata('error'));
                         }  if ($this->session->flashdata('info')) { 
                             echo  getMessage('info', $this->session->flashdata('info'));
                         }?> -->


                         
<section>
    <div class="container">
        <div class="shop">
            <h3 class="m-b-20">Explore  Airbnb</h3>
            <div class="grid-layout grid-4-columns" data-item="grid-item">
                <div class="grid-item">
                    <img style="height: 72px; width: 96px;" src="https://a0.muscache.com/im/pictures/8b7519ec-2c82-4c09-8233-fd4d2715bbf9.jpg?aki_policy=large">
                    <span>Homes</span>
                </div>
                <div class="grid-item">
                    
                    <img style="height: 72px; width: 96px;" src="https://a0.muscache.com/im/pictures/cb8b3101-d419-4c17-8e2f-4989b39b98c3.jpg?aki_policy=large">
                    <span>Experiences</span>

                </div>

                <div class="grid-item">
                     <img style="height: 72px; width: 96px;" src="https://a0.muscache.com/im/pictures/da2d8e97-90b7-409f-94ac-5ab0327c289b.jpg?aki_policy=large">
                    <span>Restaurants</span>

                </div>
            </div>
        </div>


<!--         <div class="row m-b-20">
    class class
            <div class="col-md-6 p-t-10 m-b-20">
                <h3 class="m-b-20">Lorem Ipsum</h3>
                <p>Book unique homes and experiences all over the world.</p>
            </div>
            <div class="col-md-3">
                <div class="order-select">
                    <h6>Sort by</h6>
                    <p>Showing 1&ndash;12 of 25 results</p>
                    <form method="get">
                        <select>
                            <option value="order" selected="selected">Default sorting</option>
                            <option value="popularity">Sort by popularity</option>
                            <option value="rating">Sort by average rating</option>
                            <option value="date">Sort by newness</option>
                            <option value="price">Sort by price: low to high</option>
                            <option value="price-desc">Sort by price: high to low</option>
                        </select>
                    </form>
                </div>
            </div>
            <div class="col-md-3">
                <div class="order-select">
                    <h6>Sort by Price</h6>
                    <p>From 0 - 190$</p>
                    <form method="get">
                        <select>
                            <option value="" selected="selected">0$ - 50$</option>
                            <option value="">51$ - 90$</option>
                            <option value="">91$ - 120$</option>
                            <option value="">121$ - 200$</option>
                        </select>
                    </form>
                </div>
            </div>
            

        </div> -->

        <section>
            <div class="introducing_sec">
                 <h3 class="m-b-20">Introducing Airbnb Plus</h3>
                <a href="#"><img style="width: 100%; height: 300px;" class="introducing_img" alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>Hotel-lagune-800-4002.jpg">
                            </a>
            </div>
        </section>

         <!--Product list-->
                <div class="shop">

                      <h3 class="m-b-20">Homes around the world</h3>

                    <div class="grid-layout grid-4-columns" data-item="grid-item">


                <div class="grid-item">

                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>photos_86703_2169809.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>photos_86703_2169809.jpg">
                            </a>
                            <span class="product-new">NEW</span>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="<?php echo base_url('home/room_detail'); ?>">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire House</div>
                            <div class="product-title">
                                <h3><a href="<?php echo base_url('home/room_detail'); ?>">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$15.00</ins> per/day
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">6 customer reviews</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images.jpg">
                            </a>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Home</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$39.00</ins> per night
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">3 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>Harris2.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>Harris2.jpg">
                            </a>
                            <span class="product-hot">HOT</span>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire Hosue</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$39.00</ins> per night
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">3 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>photos_86703_2169811.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>photos_86703_2169811.jpg">
                            </a>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire House</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$22.00</ins> per night
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">5 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images2.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images2.jpg">
                            </a>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire House</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$39.00</ins> per night
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">5 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images3.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images3.jpg">
                            </a>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire House</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price">
                                <ins>$15.00</ins> per night
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                            <div class="product-reviews"><a href="#">5 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images4.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images4.jpg">
                            </a>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire House</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$26.00</ins> per day
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">5 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images5.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images5.jpg">
                            </a>
                            <span class="product-sale">SALE</span>
                            <span class="product-sale-off">50% Off</span>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire Hosue</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price">
                                <del>$19.00</del><ins>$15.00</ins> per day
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">5 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>



                    <div class="grid-item">

                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>photos_86703_2169809.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>photos_86703_2169809.jpg">
                            </a>
                            <span class="product-new">NEW</span>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire House</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$15.00</ins> per/day
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">6 customer reviews</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images.jpg">
                            </a>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Home</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$39.00</ins> per night
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">3 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>Harris2.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>Harris2.jpg">
                            </a>
                            <span class="product-hot">HOT</span>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire Hosue</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$39.00</ins> per night
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">3 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>photos_86703_2169811.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>photos_86703_2169811.jpg">
                            </a>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire House</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$22.00</ins> per night
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">5 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images2.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images2.jpg">
                            </a>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire House</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$39.00</ins> per night
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">5 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images3.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images3.jpg">
                            </a>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire House</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price">
                                <ins>$15.00</ins> per night
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                            <div class="product-reviews"><a href="#">5 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images4.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images4.jpg">
                            </a>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire House</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$26.00</ins> per day
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">5 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images5.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images5.jpg">
                            </a>
                            <span class="product-sale">SALE</span>
                            <span class="product-sale-off">50% Off</span>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire Hosue</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price">
                                <del>$19.00</del><ins>$15.00</ins> per day
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">5 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>


                    <div class="grid-item">

                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>photos_86703_2169809.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>photos_86703_2169809.jpg">
                            </a>
                            <span class="product-new">NEW</span>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire House</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$15.00</ins> per/day
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">6 customer reviews</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images.jpg">
                            </a>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Home</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$39.00</ins> per night
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">3 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>Harris2.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>Harris2.jpg">
                            </a>
                            <span class="product-hot">HOT</span>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire Hosue</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$39.00</ins> per night
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">3 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>photos_86703_2169811.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>photos_86703_2169811.jpg">
                            </a>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire House</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$22.00</ins> per night
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">5 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images2.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images2.jpg">
                            </a>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire House</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$39.00</ins> per night
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">5 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images3.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images3.jpg">
                            </a>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire House</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price">
                                <ins>$15.00</ins> per night
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                            <div class="product-reviews"><a href="#">5 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images4.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images4.jpg">
                            </a>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire House</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$26.00</ins> per day
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">5 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images5.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images5.jpg">
                            </a>
                            <span class="product-sale">SALE</span>
                            <span class="product-sale-off">50% Off</span>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire Hosue</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price">
                                <del>$19.00</del><ins>$15.00</ins> per day
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">5 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
            <hr>
                    <!-- Pagination -->
                    <!-- <div class="pagination">
                        <ul>
                            <li>
                                <a href="#" aria-label="Previous"> <span aria-hidden="true"><i class="fa fa-angle-left"></i></span> </a>
                            </li>
                            <li><a href="#">1</a> </li>
                            <li><a href="#">2</a> </li>
                            <li class="active"><a href="#">3</a> </li>
                            <li><a href="#">4</a> </li>
                            <li><a href="#">5</a> </li>
                            <li>
                                <a href="#" aria-label="Next"> <span aria-hidden="true"><i class="fa fa-angle-right"></i></span> </a>
                            </li>
                        </ul>
                    </div> -->
                    <!-- end: Pagination -->
        </div>



         <!--Product list-->
                <div class="shop">

                      <h3 class="m-b-20">Experiences travelers love</h3>
                      
                    <div class="grid-layout grid-4-columns" data-item="grid-item">


                <div class="grid-item">

                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>photos_86703_2169809.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>photos_86703_2169809.jpg">
                            </a>
                            <span class="product-new">NEW</span>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire House</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$15.00</ins> per/day
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">6 customer reviews</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images.jpg">
                            </a>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Home</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$39.00</ins> per night
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">3 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>Harris2.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>Harris2.jpg">
                            </a>
                            <span class="product-hot">HOT</span>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire Hosue</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$39.00</ins> per night
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">3 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>photos_86703_2169811.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>photos_86703_2169811.jpg">
                            </a>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire House</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$22.00</ins> per night
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">5 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images2.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images2.jpg">
                            </a>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire House</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$39.00</ins> per night
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">5 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images3.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images3.jpg">
                            </a>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire House</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price">
                                <ins>$15.00</ins> per night
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                            <div class="product-reviews"><a href="#">5 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images4.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images4.jpg">
                            </a>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire House</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$26.00</ins> per day
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">5 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images5.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images5.jpg">
                            </a>
                            <span class="product-sale">SALE</span>
                            <span class="product-sale-off">50% Off</span>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire Hosue</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price">
                                <del>$19.00</del><ins>$15.00</ins> per day
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">5 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>



                    <div class="grid-item">

                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>photos_86703_2169809.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>photos_86703_2169809.jpg">
                            </a>
                            <span class="product-new">NEW</span>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire House</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$15.00</ins> per/day
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">6 customer reviews</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images.jpg">
                            </a>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Home</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$39.00</ins> per night
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">3 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>Harris2.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>Harris2.jpg">
                            </a>
                            <span class="product-hot">HOT</span>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire Hosue</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$39.00</ins> per night
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">3 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>photos_86703_2169811.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>photos_86703_2169811.jpg">
                            </a>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire House</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$22.00</ins> per night
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">5 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images2.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images2.jpg">
                            </a>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire House</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$39.00</ins> per night
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">5 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images3.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images3.jpg">
                            </a>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire House</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price">
                                <ins>$15.00</ins> per night
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                            <div class="product-reviews"><a href="#">5 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images4.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images4.jpg">
                            </a>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire House</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$26.00</ins> per day
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">5 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images5.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images5.jpg">
                            </a>
                            <span class="product-sale">SALE</span>
                            <span class="product-sale-off">50% Off</span>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire Hosue</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price">
                                <del>$19.00</del><ins>$15.00</ins> per day
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">5 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>


                    <div class="grid-item">

                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>photos_86703_2169809.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>photos_86703_2169809.jpg">
                            </a>
                            <span class="product-new">NEW</span>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire House</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$15.00</ins> per/day
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">6 customer reviews</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images.jpg">
                            </a>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Home</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$39.00</ins> per night
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">3 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>Harris2.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>Harris2.jpg">
                            </a>
                            <span class="product-hot">HOT</span>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire Hosue</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$39.00</ins> per night
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">3 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>photos_86703_2169811.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>photos_86703_2169811.jpg">
                            </a>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire House</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$22.00</ins> per night
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">5 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images2.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images2.jpg">
                            </a>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire House</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$39.00</ins> per night
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">5 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images3.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images3.jpg">
                            </a>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire House</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price">
                                <ins>$15.00</ins> per night
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                            <div class="product-reviews"><a href="#">5 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images4.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images4.jpg">
                            </a>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire House</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price"><ins>$26.00</ins> per day
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">5 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="grid-item">
                    <div class="product">
                        <div class="product-image">
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images5.jpg">
                            </a>
                            <a href="#"><img alt="Shop product image!" src="<?php echo base_url('assets/images/'); ?>images5.jpg">
                            </a>
                            <span class="product-sale">SALE</span>
                            <span class="product-sale-off">50% Off</span>
                            <span class="product-wishlist">
<a href="#"><i class="fa fa-heart"></i></a>
</span>
                            <div class="product-overlay">
                                <a href="shop-product-ajax-page.html" data-lightbox="ajax">Quick View</a>
                            </div>
                        </div>

                        <div class="product-description">
                            <div class="product-category">Entire Hosue</div>
                            <div class="product-title">
                                <h3><a href="#">I SETTE CONI - TRULLO EDERA</a></h3>
                            </div>
                            <div class="product-price">
                                <del>$19.00</del><ins>$15.00</ins> per day
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#">5 customer reviews</a>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
            <hr>
                    <!-- Pagination -->
                    <div class="pagination">
                        <ul>
                            <li>
                                <a href="#" aria-label="Previous"> <span aria-hidden="true"><i class="fa fa-angle-left"></i></span> </a>
                            </li>
                            <li><a href="#">1</a> </li>
                            <li><a href="#">2</a> </li>
                            <li class="active"><a href="#">3</a> </li>
                            <li><a href="#">4</a> </li>
                            <li><a href="#">5</a> </li>
                            <li>
                                <a href="#" aria-label="Next"> <span aria-hidden="true"><i class="fa fa-angle-right"></i></span> </a>
                            </li>
                        </ul>
                    </div>
                    <!-- end: Pagination -->
        </div>


    </div>
</section>
<!-- end: Shop products -->


<!-- DELIVERY INFO -->
<section class="background-grey p-t-40 p-b-0">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="icon-box effect small clean">
                    <div class="icon">
                        <a href="#"><i class="fa fa-phone"></i></a>
                    </div>
                    <h3>24/7 customer support</h3>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                </div>
            </div>

            <div class="col-md-4">
                <div class="icon-box effect small clean">
                    <div class="icon">
                        <a href="#"><i class="fa fa-plane"></i></a>
                    </div>
                    <h3>₹6,00,00,000 host guarantee</h3>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                </div>
            </div>

            <div class="col-md-4">
                <div class="icon-box effect small clean">
                    <div class="icon">
                        <a href="#"><i class="fa fa-history"></i></a>
                    </div>
                    <h3>Verified ID!</h3>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.!</p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- end: DELIVERY INFO -->

