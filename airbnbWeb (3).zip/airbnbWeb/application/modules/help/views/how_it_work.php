<!-- Inspiro Slider -->
<?php  $_SESSION['current_page'] = $_SERVER['REQUEST_URI'];  ?>

    <!-- end: Slide 2 -->

</div>
<!--end: Inspiro Slider -->

<section>
	<div class="container">
      <p><?php echo $pagesdata->how_it_work; ?></p>
	</div>
</section>
